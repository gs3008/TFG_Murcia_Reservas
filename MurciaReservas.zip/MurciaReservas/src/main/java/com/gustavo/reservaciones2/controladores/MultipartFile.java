package com.gustavo.reservaciones2.controladores;

public class MultipartFile {

}
