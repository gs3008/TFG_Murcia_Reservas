package com.gustavo.reservaciones2.controladores;

import java.util.List;

import com.gustavo.reservaciones2.modelos.Usuario;
import com.gustavo.reservaciones2.servicios.UsuarioServicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

//import com.gustavo.reservaciones2.modelos.Producto;
//import com.gustavo.reservaciones2.servicios.ProductoServicio;

@Controller
@RequestMapping("/public")
public class ZonaPublicaController {
	
	@Autowired
	UsuarioServicio servicio;
	
	//@Autowired
	//ProductoServicio productoServicio;
	
	
	/*@ModelAttribute("productos")
	public List<Producto> productosNoVendidos() {
		return productoServicio.productosSinVender();
	}*/
	
	
	@GetMapping({"/", "/index"})
	public String listar(Model model) {
		return "index";
	}
	
	/*@GetMapping("/producto/{id}")
	public String showProduct(Model model, @PathVariable Long id) {
		Producto result = productoServicio.findById(id); 
		if (result != null) {
			model.addAttribute("producto", result);
			return "producto";
		}
		return "redirect:/public";
	}*/
	
}
