package com.gustavo.reservaciones2.controladores;

import com.gustavo.reservaciones2.modelos.Mesa;
import com.gustavo.reservaciones2.modelos.Reserva;
import com.gustavo.reservaciones2.servicios.ReservaServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/reserva")
public class ReservaControlador {

    @Autowired
    ReservaServicio servicio;

    @GetMapping("/reservas")
    public String listar(Model model){
        List<Reserva> reservas = servicio.listar();
        model.addAttribute("reservas",reservas);
        return "reservas";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model modelo){
        modelo.addAttribute( "reserva", new Reserva());
        return  "formularioReserva";
    }

    @PostMapping("/salvar")
    public String salvarMesa(@Validated Reserva reserva , Model model) {
        servicio.salvar(reserva);
        return "redirect:/reserva/reservas";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable long id, Model model) {
        Optional<Reserva> reserva= servicio.listarId(id);
        model.addAttribute("reserva", reserva);
        return "formularioReserva";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable long id, Model model) {
        servicio.eliminar(id);
        return "redirect:/reserva/reservas";

    }
    @GetMapping("/nuevoVista")
    public String nuevoVista(Model modelo){
        modelo.addAttribute( "reserva", new Reserva());
        return  "formularioReservaNuevaVista";
    }

}
