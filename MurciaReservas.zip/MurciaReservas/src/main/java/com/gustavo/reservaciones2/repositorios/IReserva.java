package com.gustavo.reservaciones2.repositorios;

import com.gustavo.reservaciones2.modelos.Reserva;
import org.springframework.data.repository.CrudRepository;

public interface IReserva extends CrudRepository <Reserva,Long> {


}
