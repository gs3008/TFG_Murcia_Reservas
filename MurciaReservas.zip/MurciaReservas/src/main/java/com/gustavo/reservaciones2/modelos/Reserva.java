package com.gustavo.reservaciones2.modelos;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@EntityListeners(AuditingEntityListener.class)
public class Reserva {

    @Id @GeneratedValue
	private long id;

    private long idMesa;
    private String idUsuario;


	@Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date fechaReserva;

    private String horaReserva;
    private int cantidadPersona;
    private String estado;

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public long getIdMesa() {
        return idMesa;
    }
    public void setIdMesa(long idMesa) {
        this.idMesa = idMesa;
    }


    // DateTimeFormat annotation on the method that's calling the DB to get date.
    @DateTimeFormat(pattern="dd-MMM-YYYY")
    public Date getFechaReserva() {
        return fechaReserva;
    }
    public void setFechaReserva(Date fechaReserva) {
        this.fechaReserva = fechaReserva;
    }
    public String getHoraReserva() {
        return horaReserva;
    }
    public void setHoraReserva(String horaReserva) {
        this.horaReserva = horaReserva;
    }
    public int getCantidadPersona() {
        return cantidadPersona;
    }
    public void setCantidadPersona(int cantidadPersona) {
        this.cantidadPersona = cantidadPersona;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}


