package com.gustavo.reservaciones2.servicios;

import com.gustavo.reservaciones2.modelos.Mesa;
import com.gustavo.reservaciones2.modelos.Reserva;
import com.gustavo.reservaciones2.repositorios.IReserva;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReservaServicio {

    @Autowired
    IReserva ireserva;


    public List<Reserva> listar(){
        return (List<Reserva>) ireserva.findAll();
    }


    public Optional<Reserva> listarId(long id) {
        return ireserva.findById(id);
    }


    public int salvar(Reserva reserva){
        int retorno = 0;
        Reserva r =ireserva.save(reserva);
        if(!r.equals(null)){
            retorno=1;
        }
        return retorno;
    }


    public void eliminar(long id) {
        ireserva.deleteById(id);
    }
}
