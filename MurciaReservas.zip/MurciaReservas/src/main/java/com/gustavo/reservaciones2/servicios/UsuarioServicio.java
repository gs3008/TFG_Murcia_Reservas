package com.gustavo.reservaciones2.servicios;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.gustavo.reservaciones2.modelos.Usuario;
import com.gustavo.reservaciones2.repositorios.IUsuario;

 
@Service
public class UsuarioServicio {

	@Autowired //para inyección de dependencia.
	IUsuario iusuario;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	public List<Usuario> listar(){
		return (List<Usuario>) iusuario.findAll();
	
	}
	
	public int salvar(Usuario usuario) {
		int retornar = 0;
		Usuario  u = iusuario.save(usuario);
		if(!u.equals(null)) {
			retornar=1;
		}
		return retornar;
	}

	public Optional<Usuario> listarId(long id) {
        return iusuario.findById(id);
    }

	public void delete(long id){
        iusuario.deleteById(id);
    }


	public Usuario registrar(Usuario u) {
		u.setPassword(passwordEncoder.encode(u.getPassword()));
		return iusuario.save(u);
	}

}
