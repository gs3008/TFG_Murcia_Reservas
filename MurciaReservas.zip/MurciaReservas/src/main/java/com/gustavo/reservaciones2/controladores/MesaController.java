package com.gustavo.reservaciones2.controladores;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gustavo.reservaciones2.modelos.Mesa;
import com.gustavo.reservaciones2.servicios.MesaServicio;


@Controller
@RequestMapping("/mesa")
public class MesaController {
	@Autowired
	MesaServicio servicio;
	
	//Método Mesa 
	//los listados siempre van con esta notación
	@GetMapping ("/mesas")
	public String listar(Model model) {
		List<Mesa>mesas = servicio.mesas();
		model.addAttribute("mesas",mesas);
		return "mesas"; //es el nombre de la página que se va a mostrar.
		
	}
	@GetMapping("/nuevo")
	public String nuevo(Model model) {
		model.addAttribute("mesa",new Mesa());
		return "formularioMesa";
		
	}
	
	@PostMapping("/salvar")
	public String salvarMesa(@Validated Mesa mesa , Model model) {
		servicio.salvar(mesa);
		return "redirect:/mesa/mesas";
	}
	
	@GetMapping("/editar/{id}")
    public String editar(@PathVariable long id, Model model) {
        Optional<Mesa>mesa= servicio.listarId(id);
        model.addAttribute("mesa", mesa);
        return "formularioMesa";
    }

	@GetMapping("/eliminar/{id}")
	public String eliminar(@PathVariable long id, Model model) {
		servicio.eliminar(id);
		return "redirect:/mesa/mesas";
		
	}

}
