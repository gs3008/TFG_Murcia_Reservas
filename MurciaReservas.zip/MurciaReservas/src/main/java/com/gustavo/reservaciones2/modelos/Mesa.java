package com.gustavo.reservaciones2.modelos;

import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Entity
@EntityListeners(AuditingEntityListener.class)
public class Mesa {
	@Id @GeneratedValue
	private long id;

    private int numero;
    private int cantidadPersona;
    private String referenciaUbicacion;
    private String activo;  // disponible o no
    private String estado; //operativa o no
    
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public int getNumero() {
        return numero;
    }
    public void setNumero(int numero) {
        this.numero = numero;
    }
    public int getCantidadPersona() {
        return cantidadPersona;
    }
    public void setCantidadPersona(int cantidadPersona) {
        this.cantidadPersona = cantidadPersona;
    }
    public String getReferenciaUbicacion() {
        return referenciaUbicacion;
    }
    public void setReferenciaUbicacion(String referenciaUbicacion) {
        this.referenciaUbicacion = referenciaUbicacion;
    }

    public String getActivo() {return activo;}

    public void setActivo(String activo) {
        this.activo = activo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
