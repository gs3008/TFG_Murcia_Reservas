package com.gustavo.reservaciones2.repositorios;
import org.springframework.data.repository.CrudRepository;
import com.gustavo.reservaciones2.modelos.Mesa;


public interface IMesa  extends CrudRepository<Mesa, Long>{

	
}
