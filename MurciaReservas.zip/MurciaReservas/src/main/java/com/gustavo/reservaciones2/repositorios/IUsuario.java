package com.gustavo.reservaciones2.repositorios;

import org.springframework.data.repository.CrudRepository;

import com.gustavo.reservaciones2.modelos.Usuario;


public interface IUsuario  extends CrudRepository<Usuario, Long>{
    
    Usuario findFirstByEmail(String email);
    //Usuario findFirstByEmail(String username);
    
    //Usuario findByUsuario(String usuario);
}
