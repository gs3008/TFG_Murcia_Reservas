package com.gustavo.reservaciones2.modelos;

public class Date {

}
