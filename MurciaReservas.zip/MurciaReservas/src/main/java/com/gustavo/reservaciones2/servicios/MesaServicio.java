package com.gustavo.reservaciones2.servicios;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gustavo.reservaciones2.modelos.Mesa;
import com.gustavo.reservaciones2.repositorios.IMesa;

@Service
public class MesaServicio {
	
	@Autowired
	IMesa imesa;
	
	
	public List<Mesa> mesas(){   // Método para listar todos los elementos de mesa
		 return (List<Mesa>) imesa.findAll();
		
	}
	
	public Optional<Mesa> listarId(long id) {
        return imesa.findById(id);
    }

	public int salvar(Mesa mesa){
		int retorno = 0;
		Mesa m = imesa.save(mesa);
		if(!m.equals(null)) {
			retorno=1;
		}
		return retorno;
	}
	
	public void eliminar(long id) {
		imesa.deleteById(id);
	}
	
	
	
}
