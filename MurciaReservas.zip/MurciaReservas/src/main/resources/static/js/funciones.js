function eliminar(id){
    swal.fire({
        title: '¿Está seguro?',
        text: "¡No podrás revertir esto!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si, ¡bórralo!',
    }).then((result) => {
        if (result.value){
            $.ajax({
                url:"/eliminar/"+id
            })
            .done(function(response){
                swal.fire('¡Eliminado!', response.message, response.status).then((ok)=>{
                    if(ok){
                        location.href="/listar";
                    }
                });
            })
            .fail(function(){
                swal.fire('Ups...', '¡Algo salió mal con ajax!', 'error');
            });
        }

    });
}